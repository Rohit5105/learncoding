
public class Application 
{
    public static void main(String[] args) {
        BankFactory bankFactory = new MMBankFactory();

        SavingAcc saving = new MMSavingAcc(1, "Rohit", 10000, true);
        CurrentAcc current = new MMCurrentAcc(2, "Yash", 20000, 2000);

        saving.withdraw(1000);
        current.withdraw(5000);

        System.out.println(saving.toString());
        System.out.println(current.toString());
    }
}
