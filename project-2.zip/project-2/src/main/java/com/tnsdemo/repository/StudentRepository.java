package com.tnsdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tnsdemo.entity.Student_Info;



public interface StudentRepository extends JpaRepository<Student_Info, Integer > {

}

