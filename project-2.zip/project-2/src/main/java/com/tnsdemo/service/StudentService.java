package com.tnsdemo.service;

import java.security.cert.Certificate;
import java.util.List;

import java.util.NoSuchElementException;

import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import com.tnsdemo.entity.Student_Info;
import com.tnsdemo.repository.StudentRepository;

@Service

@Transactional

public class StudentService {

	@Autowired
	StudentRepository studentRepo;

	// A service method to Add student

	public void addStudent(Student_Info student) {

		studentRepo.save(student);
	}

	// Method to Update the Student Details using Id

	public String updateStudent(Student_Info student, long id) {

		if (searchStudentById(id) == null) {

			return "Student Not Found for updation";

		} else {

			studentRepo.save(student);

			return "Record updated successfully";

		}

	}
	// Method to search Student using Id

	public Student_Info searchStudentById(long id) {

		try {

			Optional<Student_Info> op = studentRepo.findById((int) id);

			return op.get();

		} catch (NoSuchElementException e) {

			System.out.println("No record found");

		}

		return null;

	}

	// Method to search Student using Id

		public Student_Info searchStudentByHallTicket(long TicketNo) {

			try {

				Optional<Student_Info> op = studentRepo.findById((int) TicketNo);

				return op.get();

			} catch (NoSuchElementException e) {

				System.out.println("No record found");

			}

			return null;

		}

	// A service method to Add student

	public void addCertificate(Certificate certificate) {

		//studentRepo.save(certificate);

	}	

	public void updateCertificates(Certificate certificate) {

	}

	// Method to delete Student using id

	public boolean deletelStudentById(long id) {

		studentRepo.deleteById((int) id);

		if (searchStudentById(id) == null) {

			return true;

		}

		return false;

	}

	// Method to retrieve all Students

	public List<Student_Info> getAllStudents() {

		return studentRepo.findAll();

	}

}