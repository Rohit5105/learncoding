package com.tnsdemo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student_Info {
	@Id
	private long studentId;
	private String name;
	private long roll;
	private String qualification;
	private String course;
	private int year;
	private long hallTicketNo;
	private String college ;
	 private String Certificate;
	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRoll() {
		return roll;
	}
	public void setRoll(long roll) {
		this.roll = roll;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public long getHallTicketNo() {
		return hallTicketNo;
	}
	public void setHallTicketNo(long hallTicketNo) {
		this.hallTicketNo = hallTicketNo;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getCertificate() {
		return Certificate;
	}
	public void setCertificate(String certificate) {
		Certificate = certificate;
	}
	
	public Student_Info() {
		super();
		this.college = college;
		this.Certificate = Certificate;
	}
	public Student_Info(long studentId, String name, long roll, String qualification, String course, int year,
			long hallTicketNo, String college, String certificate) {
	     super();
		this.studentId = studentId;
		this.name = name;
		this.roll = roll;
		this.qualification = qualification;
		this.course = course;
		this.year = year;
		this.hallTicketNo = hallTicketNo;
		this.college = college;
		this.Certificate = certificate;
	}
	@Override
	public String toString() {
		return "Student_Info [studentId=" + studentId + ", name=" + name + ", roll=" + roll + ", qualification="
				+ qualification + ", course=" + course + ", year=" + year + ", hallTicketNo=" + hallTicketNo
				+ ", college=" + college + ", Certificate=" + Certificate + "]";
	}
	 
}
